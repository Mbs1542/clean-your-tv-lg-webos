from updater.cli import entry
entry()
